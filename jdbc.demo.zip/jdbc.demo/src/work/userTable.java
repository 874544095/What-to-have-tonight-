package work;
//user表的实体类
public class userTable {
    //实体类中 基本数据类型建议使用其对应的包装类型
    private Integer id;
    private String useName;
    private String email;
    private String password;
    //alt+insert
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUseName() {
        return useName;
    }

    public void setUseName(String useName) {
        this.useName = useName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    //地址转换为信息
    public String toString() {
        return "userTable{" +
                "id=" + id +
                ", useName='" + useName + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
