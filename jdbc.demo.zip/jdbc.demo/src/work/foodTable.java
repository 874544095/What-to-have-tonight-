package work;

public class foodTable {
    private Integer id;
    private String name;
    private String canteen;
    private String floor;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCanteen() {
        return canteen;
    }

    public void setCanteen(String canteen) {
        this.canteen = canteen;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    @Override
    public String toString() {
        return "foodTable{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", canteen='" + canteen + '\'' +
                ", floor='" + floor + '\'' +
                '}';
    }
}
