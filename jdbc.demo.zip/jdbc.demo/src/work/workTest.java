package work;

import com.alibaba.druid.pool.DruidDataSourceFactory;
import org.junit.Test;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class workTest{
    public int GetUserSum(Connection conn) throws Exception{
        String sql="select * from itcast.user;";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        ResultSet rs = pstmt.executeQuery(sql);
        rs.last();
        int total = rs.getRow();
        rs.close();
        pstmt.close();
        return total;
    }
    public int GetFoodSum(Connection conn) throws Exception{
        String sql="select * from itcast.food;";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        ResultSet rs = pstmt.executeQuery(sql);
        rs.last();
        int total = rs.getRow();
        rs.close();
        pstmt.close();
        return total;
    }
    public void ReadAllUser(Connection conn) throws Exception {
        //2 定义sql语句
        String sql="select * from itcast.user;";
        //3 获取pstmt对象
        PreparedStatement pstmt = conn.prepareStatement(sql);
        //4 设置参数
        //5 执行sql
        ResultSet rs = pstmt.executeQuery(sql);
        //6 处理结果 List <userTable>封装userTable对象 装载List集合
        List<userTable> uts=new ArrayList<>();
        while(rs.next()){
            //获取数据
            int id = rs.getInt("id");
            String useName = rs.getString("useName");
            String email = rs.getString("email");
            String password = rs.getString("password");
            //封装对象
            userTable ut=new userTable();
            ut.setId(id);
            ut.setUseName(useName);
            ut.setEmail(email);
            ut.setPassword(password);
            //装载集合
            uts.add(ut);
        }
        //打印结果
        System.out.println(uts);
        rs.close();
        pstmt.close();
    }
    public void ReadCertainUser(Connection conn,int _id) throws Exception {
        //2 定义sql语句
        String sql="select * from itcast.user where id="+_id+';';//若只设置一个参数时会报错
        //3 获取pstmt对象
        PreparedStatement pstmt = conn.prepareStatement(sql);
        //4 设置参数
        //5 执行sql
        ResultSet rs = pstmt.executeQuery(sql);
        //6 处理结果 List <userTable>封装userTable对象 装载List集合
        List<userTable> uts=new ArrayList<>();
        while(rs.next()){
            //获取数据
            int id = rs.getInt("id");
            String useName = rs.getString("useName");
            String email = rs.getString("email");
            String password = rs.getString("password");
            //封装对象
            userTable ut=new userTable();
            ut.setId(id);
            ut.setUseName(useName);
            ut.setEmail(email);
            ut.setPassword(password);
            //装载集合
            uts.add(ut);
        }
        //打印结果
        System.out.println(uts);
        rs.close();
        pstmt.close();
    }
    public void ReadAllFood(Connection conn) throws Exception {
        String sql="select * from itcast.food;";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        ResultSet rs = pstmt.executeQuery(sql);

        List<foodTable> fds=new ArrayList<>();
        while(rs.next()){

            int id = rs.getInt("id");
            String name = rs.getString("name");
            String canteen = rs.getString("canteen");
            String floor = rs.getString("floor");

            foodTable fd=new foodTable();
            fd.setId(id);
            fd.setName(name);
            fd.setCanteen(canteen);
            fd.setFloor(floor);

            fds.add(fd);
        }

        System.out.println(fds);
        rs.close();
        pstmt.close();
         ;
    }
    public void ReadCertainFood(Connection conn,int _id) throws Exception {
        String sql="select * from itcast.food where id="+_id+';';

        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery(sql);

        List<foodTable> fds=new ArrayList<>();
        while(rs.next()){

            int id = rs.getInt("id");
            String name = rs.getString("name");
            String canteen = rs.getString("canteen");
            String floor = rs.getString("floor");

            foodTable fd=new foodTable();
            fd.setId(id);
            fd.setName(name);
            fd.setCanteen(canteen);
            fd.setFloor(floor);

            fds.add(fd);
        }

        System.out.println(fds);
        rs.close();
        pstmt.close();
         
    }
    public void CreateUser(Connection conn,String _useName,String _email,String _password) throws Exception {
        //2 定义sql语句

        String sql="insert into itcast.user(id,useName,email,password)values(?,?,?,?)";
        //3 获取pstmt对象
        PreparedStatement pstmt = conn.prepareStatement(sql);
        //4 设置参数
        int _sum=GetUserSum(conn);
        pstmt.setInt(1,_sum+1);
        pstmt.setString(2,_useName);
        pstmt.setString(3,_email);
        pstmt.setString(4,_password);
        //5 执行sql
        int cnt = pstmt.executeUpdate();
        //6 处理结果
        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void CreateFood(Connection conn,String _name,String _canteen,String _floor) throws Exception {
        String sql="insert into itcast.food(id,name,canteen,floor)values(?,?,?,?)";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        int _sum=GetFoodSum(conn);
        pstmt.setInt(1,_sum+1);
        pstmt.setString(2,_name);
        pstmt.setString(3,_canteen);
        pstmt.setString(4,_floor);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void UpdateUser(Connection conn,int _id,String _useName,String _email,String _password) throws Exception {
        String sql="update itcast.user set useName = ?,email = ?,password = ? where id = ?";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        pstmt.setString(1,_useName);
        pstmt.setString(2,_email);
        pstmt.setString(3,_password);
        pstmt.setInt(4,_id);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void UpdateFood(Connection conn,int _id,String _name,String _canteen,String _floor) throws Exception {
        String sql="update itcast.food set name = ?,canteen = ?,floor = ? where id = ?";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        pstmt.setString(1,_name);
        pstmt.setString(2,_canteen);
        pstmt.setString(3,_floor);
        pstmt.setInt(4,_id);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void DeleteUser(Connection conn,int _id) throws Exception {
        String sql="delete from itcast.user where id = ?";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        pstmt.setInt(1,_id);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void DeleteFood(Connection conn,int _id) throws Exception {
        String sql="delete from itcast.food where id = ?";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        pstmt.setInt(1,_id);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void FavorIt(Connection conn,int _useName,int _foodId) throws Exception {
        String sql="insert into itcast.favor(user_id,food_id)values(?,?)";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        pstmt.setInt(1,_useName);
        pstmt.setInt(2,_foodId);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void CancelFavor(Connection conn,int _useName,int _foodId) throws Exception {
        String sql="delete from favor where user_id=?,food_id=?";

        PreparedStatement pstmt = conn.prepareStatement(sql);

        pstmt.setInt(1,_useName);
        pstmt.setInt(2,_foodId);

        int cnt = pstmt.executeUpdate();

        System.out.println(cnt>0);

        pstmt.close();
         
    }
    public void ReadSpecFood(Connection conn,String _canteen,String _floor) throws Exception {
        String sql="select * from itcast.food where canteen = '"+_canteen + "'and floor = '"+_floor+"';";

        PreparedStatement pstmt = conn.prepareStatement(sql);
        System.out.println(sql);
        ResultSet rs = pstmt.executeQuery(sql);

        List<foodTable> fds=new ArrayList<>();
        while(rs.next()){

            int id = rs.getInt("id");
            String name = rs.getString("name");
            String canteen = rs.getString("canteen");
            String floor = rs.getString("floor");

            foodTable fd=new foodTable();
            fd.setId(id);
            fd.setName(name);
            fd.setCanteen(canteen);
            fd.setFloor(floor);

            fds.add(fd);
        }

        System.out.println(fds);
        rs.close();
        pstmt.close();
         
    }
    public static void main(String[] args) throws Exception{
        //利用druid对数据池进行连接
        Properties prop = new Properties();
        prop.load(new FileInputStream("C:/Users/闫星舟/IdeaProjects/jdbc/jdbc.demo/src/druid.properties"));
        DataSource dataSource = DruidDataSourceFactory.createDataSource(prop);
        Connection conn = dataSource.getConnection();
        //成功获取连接 得到实例化对象conn
        int opt=9;
        Scanner sc=new Scanner(System.in);
        do{
            System.out.println("对用户进行CRUD      请输入1");
            System.out.println("对食物进行CRUD      请输入2");
            System.out.println("收藏/取消收藏食物    请输入3");
            System.out.println("随机一个食物         请输入4");
            System.out.println("根据食堂楼层查询食物  请输入5");
            System.out.println("结束程序             请输入0");
            System.out.println("请输入操作:");
            opt= sc.nextInt();
            workTest wkT=new workTest();
            int id1,id2,opt2;
            String x,y,z;
            switch (opt) {
                case 1:
                    System.out.println("查询所有用户信息   输入1");
                    System.out.println("查询指定id用户信息 输入2");
                    System.out.println("增加用户信息       输入3");
                    System.out.println("更新用户信息       输入4");
                    System.out.println("删除用户信息       输入5");
                    opt2 = sc.nextInt();
                    switch (opt2) {
                        case 1:
                            wkT.ReadAllUser(conn);
                            break;
                        case 2:
                            System.out.println("请输入用户id");
                            id1 = sc.nextInt();
                            wkT.ReadCertainUser(conn,id1);
                            break;
                        case 3:
                            System.out.println("请依次输入插入用户的姓名 邮箱 密码");
                            x = sc.next();
                            y = sc.next();
                            z = sc.next();
                            wkT.CreateUser(conn,x,y,z);
                            break;
                        case 4:
                            System.out.println("请依次输入需要更改的用户的id 更改后的姓名 邮箱 密码");
                            id1 = sc.nextInt();
                            x = sc.next();
                            y = sc.next();
                            z = sc.next();
                            wkT.UpdateUser(conn,id1, x, y, z);
                            break;
                        case 5:
                            System.out.println("请输入需要删除信息的用户的id");
                            id1 = sc.nextInt();
                            wkT.DeleteUser(conn,id1);
                            break;
                    }
                    break;
                case 2:
                    System.out.println("查询所有食物信息   输入1");
                    System.out.println("查询指定id食物信息 输入2");
                    System.out.println("增加食物信息       输入3");
                    System.out.println("更新食物信息       输入4");
                    System.out.println("删除食物信息       输入5");
                    opt2 = sc.nextInt();
                    switch (opt2) {
                        case 1:
                            wkT.ReadAllFood(conn);
                            break;
                        case 2:
                            System.out.println("请输入食物id");
                            id1 = sc.nextInt();
                            wkT.ReadCertainFood(conn,id1);
                            break;
                        case 3:
                            System.out.println("请依次输入插入食物的名字 食堂(如“梅苑食堂”) 楼层(如“F3”)");
                            x = sc.next();
                            y = sc.next();
                            z = sc.next();
                            wkT.CreateFood(conn,x, y, z);
                            break;
                        case 4:
                            System.out.println("请依次输入需要更改的食物的id 更改后的名称 食堂 楼层");
                            id1 = sc.nextInt();
                            x = sc.next();
                            y = sc.next();
                            z = sc.next();
                            wkT.UpdateFood(conn,id1, x, y, z);
                            break;
                        case 5:
                            System.out.println("请输入需要删除信息的食物的id");
                            id1 = sc.nextInt();
                            wkT.DeleteFood(conn,id1);
                            break;
                    }
                    break;
                case 3:
                    System.out.println("收藏某个食物     输入1");
                    System.out.println("取消收藏某个食物  输入2");
                    opt2 = sc.nextInt();
                    switch (opt2) {
                        //不太清楚具体收藏需要实现怎么样的功能 实现到什么地步，先写着,后面对接一下网上再迭代
                        case 1:
                            System.out.println("请依次输入用户id 食物id");
                            id1 = sc.nextInt();
                            id2 = sc.nextInt();
                            wkT.FavorIt(conn,id1, id2);
                            break;
                        case 2:
                            System.out.println("请输入需要取消收藏的食物相关的用户id 食物id");
                            id1 = sc.nextInt();
                            id2 = sc.nextInt();
                            wkT.CancelFavor(conn,id1, id2);
                            break;
                    }
                    break;
                case 4:
                    int total = wkT.GetFoodSum(conn);//得到当前食物总数
                    Random rand = new Random();
                    id1 = rand.nextInt(total)+1;
                    wkT.ReadCertainFood(conn,id1);
                    break;
                case 5:
                    System.out.println("请输入需要查询食物的食堂(如“梅苑食堂”) 楼层(如F3或者输入“__”进行模糊搜索)");
                    x = sc.next();
                    y = sc.next();
                    wkT.ReadSpecFood(conn,x,y);
                    break;
            }
        }while(opt!=0);
        conn.close();
    }
}
//druid的配置必须写绝对路径不然找不到文件
//sql语句 关于查询指定食堂楼层的食物时 比如 floor= _floor 记得要在_floor两边加上单引号
//使用了sql语句 jdbc框架 druid包提供数据连接池连接操作
//还需要使用maven建构 mybatis简化开发 mapper代理开发
//这里为了保证id的连续，而不至于随机一个食物等操作随机到的id未被使用 采取了每次插入时获取总数据量sum，并使当前id=sum+1的操作
//收藏操作
//readcertain 操作为什么不能设置参数，而是只能采用字符串拼接的方式实现？？不然就会提示sql语句错误
//学长说的用maven单元测试，我采用了主函数分布询问,因为@Test测试一个方法 不支持带参测试 想办法解决
//对于resultset等API不熟