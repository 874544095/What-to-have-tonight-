package test;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class exercise {
    //根据obj的类型（user或者food）传入四个参数进行插入
  /*  public static String  AddInfor(String obj,int x,String y,String z,String w)
    {
        String sql;
        if(obj.equals("user"))return sql="insert into user(id,usename,email,password)values("+ x + ',' +y+','+z+','+w+");";
        else if (obj.equals("food"))return sql="insert into user(id,name,canteen,floor)values("+x+','+y+','+z+','+w+");";
    }
    //根据obj的类型，删除掉指定id的信息
    public static String DelInfor(String obj,int id)
    {
        String sql;
        return sql="delete form "+obj+" where id="+id;
    }
    //根据obj的类型，修改指定id的后三个数据
    public static String  UpdateInfor(String obj,int x,String y,String z,String w)
    {
        String sql;
        if(obj.equals("user"))return sql="update user(id=,usename,email,password)values("+ x + ',' +y+','+z+','+w+");";
        else if (obj.equals("food"))return sql="insert into user(id,name,canteen,floor)values("+x+','+y+','+z+','+w+");";
    }
    //*/
    public static void main(String[] args) throws Exception{
        //注册驱动
        Class.forName("com.mysql.jdbc.Driver");
        //获取连接
        String url="jdbc:mysql://127.0.0.1:3306/itcast";
        String username="root";
        String password="yxz13649079731";
        Connection conn=DriverManager.getConnection(url,username,password);
        //获取执行sql的对象
        Statement stmt=conn.createStatement();
        //定义sql语句
        String sql="select * from user";
        //stmt.executeUpdate(sql);
        //释放资源
        stmt.close();
        conn.close();
    }
}


